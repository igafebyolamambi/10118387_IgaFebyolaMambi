package com.example.uts_akb_10118387_if_9_igafebyolamambi;

public class MostViewedHelperClass {
    int image;
    String title;

    public MostViewedHelperClass(int image, String title, String description) {
        this.image = image;
        this.title = title;
    }

    public MostViewedHelperClass(int image, String title) {
    }

    public int getImage() {
        return image;
    }

    public String getTitle() {
        return title;
    }

}
